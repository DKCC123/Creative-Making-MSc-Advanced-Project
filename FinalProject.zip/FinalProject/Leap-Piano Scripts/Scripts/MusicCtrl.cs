﻿using SonicBloom.Koreo;
using SonicBloom.Koreo.Players;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Analytics;

public class MusicCtrl : MonoBehaviour
{
    public GameObject cube;
    public AudioSource audioSource;
    public SimpleMusicPlayer simpleMusicPlayer;
    public CubeListCtrl[] cubeListCtrls;

    //其他
    [Tooltip("开始播放音频之前提供的时间量（以秒为单位），也就是提前调用时间")]
    public float leadInTime;
    //音频播放之前的剩余时间量
    float leadInTimeLeft;
    //音乐开始之前的倒计时器
    float timeLeftToPlay;

    [EventID]
    public string eventID;

    private float laneNum;
    private Vector3 position;
    private Quaternion rotation;

    private void Start()
    {
        InitializeLeadIn();
        Koreographer.Instance.RegisterForEvents(eventID, transformGameObject);
    }
    public void Update()
    {
        if (timeLeftToPlay > 0)
        {
            timeLeftToPlay -= Time.unscaledDeltaTime;

            if (timeLeftToPlay <= 0)
            {
                audioSource.Play();
                timeLeftToPlay = 0;
            }
        }
        //倒数我们的引导时间
        if (leadInTimeLeft > 0)
        {
            leadInTimeLeft = Mathf.Max(leadInTimeLeft - Time.unscaledDeltaTime, 0);
        }
    }
    /// <summary>
    /// 初始化引导时间
    /// </summary>
    void InitializeLeadIn()
    {
        if (leadInTime > 0)
        {
            leadInTimeLeft = leadInTime;
            timeLeftToPlay = leadInTime;
        }
        else
        {
            audioSource.Play();
        }
    }
    private void OnDestroy()
    {
        if (Koreographer.Instance != null)
        {
            Koreographer.Instance.UnregisterForAllEvents(this);
        }
    }

    private void transformGameObject(KoreographyEvent evt)
    {
        int num = Random.Range(0,10);
        GameObject go = Instantiate(cube, cubeListCtrls[num].transform);
        go.transform.localPosition = new Vector3(-0.2f + num * 0.05f,0.05f,2);
        cubeListCtrls[num].Add(go);
    }
}
