﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class TouchCtrl : MonoBehaviour
{
    Material myMat;
    public Material red;
    private float delay = 0.3f;

    public GameObject objAni;
	void Start ()
	{
        myMat = GetComponent<Renderer>().material;
	}

    private void OnTriggerEnter(Collider collision)
    {
        if(collision.CompareTag("Touch"))
        {
            AudioManager.instance.PlayAudio(gameObject.name);
            objAni.SetActive(true);
            CancelInvoke("DelyTime");
            Invoke("DelyTime",1);
            PlayKey();
        }
    }
    private void DelyTime()
    {
        objAni.SetActive(false);
    }

    public void PlayKey()
    {
        StartCoroutine(WaitToTurnBack());
    }

    IEnumerator WaitToTurnBack()
    {
        GetComponent<Renderer>().material = red;
        yield return new WaitForSeconds(delay);
        GetComponent<Renderer>().material = myMat;
    }
}
