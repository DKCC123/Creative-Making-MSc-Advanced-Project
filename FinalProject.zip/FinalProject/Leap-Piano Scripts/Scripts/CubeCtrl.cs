﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeCtrl : MonoBehaviour
{
    public float speed = 5;
    public void Update()
    {
        transform.Translate(Vector3.back * Time.deltaTime * speed);
        if (transform.localPosition.z <= 0)
        {
            Destroy(gameObject);
        }
    }

}
