﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeListCtrl : MonoBehaviour
{
    Queue queue = new Queue();
    public void Add(GameObject obj)
    {
        queue.Enqueue(obj);
    }
    public void Peek()
    {
        queue.Peek();
    }
    public void Remove()
    {
        queue.Dequeue();
    }
}
